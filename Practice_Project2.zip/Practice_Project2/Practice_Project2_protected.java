package assistedPracticeProject;
import packages.*;
public class Practice_Project2_protected extends Practice_Project2_packagemethod
{
	public static void main(String args[])
	{
		System.out.println("PROTECTED ACCESS MODIFIER\n");
		Practice_Project2_protected d1=new Practice_Project2_protected();
		d1.read();
	}
}
