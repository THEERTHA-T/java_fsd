package packages;

import java.util.Scanner;

public class Practice_Project2_packagemethod 
{
	protected void read()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age:");
		int age=sc.nextInt();
		System.out.println("AGE = "+age);
		
	}
}
