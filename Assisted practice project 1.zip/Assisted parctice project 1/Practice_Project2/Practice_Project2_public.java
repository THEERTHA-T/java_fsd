package assistedPracticeProject;
import packages.*;
public class Practice_Project2_public 
{
	public static void main(String args[])
	{
		System.out.println("PUBLIC ACCESS MODIFIER\n");
		Practice_Project2_publicmethod d1=new Practice_Project2_publicmethod();
		d1.read();
	}
	
}
